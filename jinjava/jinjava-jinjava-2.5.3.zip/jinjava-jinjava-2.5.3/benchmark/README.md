Jinjava Benchmarks
==================

To Run:

    mvn clean package
    java -jar target/benchmarks.jar


