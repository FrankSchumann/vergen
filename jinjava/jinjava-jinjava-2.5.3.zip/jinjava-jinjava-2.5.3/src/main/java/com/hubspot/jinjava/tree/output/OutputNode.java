package com.hubspot.jinjava.tree.output;

public interface OutputNode {
  String getValue();

  long getSize();
}
