package com.hubspot.jinjava.interpret.errorcategory;

public interface TemplateErrorCategory {}
