package com.hubspot.jinjava.random;

public enum RandomNumberGeneratorStrategy {
  THREAD_LOCAL,
  CONSTANT_ZERO,
  DEFERRED
}
